package com.sendcloud.sdk.exception;

public interface SCException {

	public String getMessage();
}