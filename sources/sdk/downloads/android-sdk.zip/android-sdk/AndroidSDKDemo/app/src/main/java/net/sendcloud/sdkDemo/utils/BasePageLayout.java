package net.sendcloud.sdkDemo.utils;

import android.content.Context;
import android.view.ViewGroup;
import android.widget.LinearLayout;

abstract class BasePageLayout {
    protected LinearLayout layout = null;
    protected Context context;

    protected BasePageLayout(Context c){
        context = c;
        layout = new LinearLayout(context);
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        layout.setLayoutParams(params);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xffffffff);

        TitleBar titleBar = new TitleBar(context);
        titleBar.setTitle("选择国家和地区");

        layout.addView(titleBar);
        onCreateContent(layout);
    }

    public LinearLayout getLayout(){
        return layout;
    }

    protected abstract void onCreateContent(LinearLayout parent);
}
