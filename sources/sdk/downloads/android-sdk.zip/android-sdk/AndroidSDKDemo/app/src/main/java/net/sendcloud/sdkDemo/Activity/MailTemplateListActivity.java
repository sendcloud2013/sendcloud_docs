package net.sendcloud.sdkDemo.Activity;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Toast;


import net.sendcloud.sdkDemo.adapter.MailTemplateAdapter;

import net.sendcloud.sdkDemo.xlistview.XListView;
import net.sendcloud.sdkDemo.xlistview.XListView.IXListViewListener;

import net.sendcloud.sendcloudmaillib.mail.MailApi;
import net.sendcloud.sendcloudmaillib.mail.MailApi.ResultCallBack;
import net.sendcloud.sendcloudmaillib.utils.StringUtil;
import net.sendcloud.sendcloudsmslib.utils.JsonUtil;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static android.R.id.list;


import net.sendcloud.androidsdk.R;
import android.os.Handler;
import android.os.Message;

public class MailTemplateListActivity extends AppCompatActivity implements IXListViewListener{

    private XListView xlistview;

    private MailApi mailApi; //邮件sdk主对象

    private List<Map<String, Object>> mapList;

    private MailTemplateAdapter mailTemplateAdapter;

    private Integer start = 0;

    private Integer limit = 10;

    private boolean hasMore=false;

    private boolean reflash=false;

    public  Handler messageHandler;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_template_list);
        xlistview = (XListView) findViewById(list);
        xlistview.setPullLoadEnable(true);
        xlistview.setRefreshTime();
        xlistview.setXListViewListener(this,1);
        //初始化sdk主操作对象
        mailApi =  MailApi.getInstance();

        messageHandler = new Handler(){
            public void handleMessage(Message msg) {
                if (msg.what == 1) {
                    int position =  msg.arg1;
                    Map<String, Object> map = mapList.get(position);
                    Intent intent = new Intent();
                    intent.putExtra("name",map.get("name").toString());
                    intent.putExtra("invokeName",map.get("invokeName").toString());
                    intent.putExtra("subject",map.get("subject").toString());
                    setResult(Activity.RESULT_OK, intent);
                    finish();
                }
            }
        };


        //适配器添加查询结果，并加到ListView中显示
        getMailTemplateList();
    }

    private void getMailTemplateList(){
        mapList = new ArrayList<Map<String, Object>>();
        start = 0;
        reflash = true;
        getDataList();
    }

    private void getMailTemplateListMore() {
        start = start + limit;
        reflash = false;
        getDataList();
    }

    private void getDataList() {
        /**
         * 获取邮件模板列表
         *
         * code	返回码: 200 成功; 500 错误;(服务器返回)
         * -2 本地网络异常; -3 服务器网络异常;-4 解析错误;-5初始化异常;
         * -6 发送者地址不正确 ; -7 接收者地址不正确;-8 邮件标题为空 -9 邮件内容为空
         * result	返回结果,JSON格式.错误或者无返回值时为空.
         * message 返回信息 成功或错误原因.
         */
        String templateType = "0";// 邮件模板类型:0 触发 1 批量
        mailApi.getMailTemplateSimple(templateType,start,limit, new ResultCallBack() {

            @Override
            public void onResult(int code, String result, String message) {
                // TODO Auto-generated method stub
                if(code == 200){
                    //调用成功
                    if(!StringUtil.isNullOrEmpty(result)){
                        Log.d("send_result", result);
                        try{
                            JSONObject jsonObject = new JSONObject(result);
                            JSONArray list = jsonObject.optJSONArray("dataList");
                            if(list!=null){
                                if(reflash){
                                    mapList = (List<Map<String, Object>>) JsonUtil.jsonParse(list.toString());
                                }else{
                                    mapList.addAll((List<Map<String, Object>>) JsonUtil.jsonParse(list.toString()));
                                }
                                haveMoreList();
                            }
                        }catch (JSONException e){

                        }
                    }
                }else { //返回错误消息
                    Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    private void  haveMoreList(){
        hasMore = false;
        /**
         * 获取邮件模板列表
         *
         * code	返回码: 200 成功; 500 错误;(服务器返回)
         * -2 本地网络异常; -3 服务器网络异常;-4 解析错误;-5初始化异常;
         * -6 发送者地址不正确 ; -7 接收者地址不正确;-8 邮件标题为空 -9 邮件内容为空
         * result	返回结果,JSON格式.错误或者无返回值时为空.
         * message 返回信息 成功或错误原因.
         */
        String templateType = "0";// 邮件模板类型:0 触发 1 批量
        mailApi.getMailTemplateSimple(templateType,start+limit,limit, new ResultCallBack() {

            @Override
            public void onResult(int code, String result, String message) {
                // TODO Auto-generated method stub
                if(code == 200){
                    //调用成功
                    if(!StringUtil.isNullOrEmpty(result)){
                        Log.d("send_result", result);
                        try{
                            JSONObject jsonObject = new JSONObject(result);
                            Integer count = jsonObject.optInt("count");
                            if(count>0){
                                hasMore = true;
                            }
                        }catch (JSONException e){

                        }
                    }
                }
                changListView();
            }
        });
    }


    private void changListView(){
        if(hasMore){
            xlistview.setPullLoadEnable(true);
        }else{
            xlistview.setPullLoadEnable(false);
        }
        xlistview.setRefreshTime();
        xlistview.stopRefresh();
        xlistview.stopLoadMore();
        if(mapList.size()==0){
            xlistview.setVisibility(View.GONE);
            if(mailTemplateAdapter != null) {
                mailTemplateAdapter.list = mapList;
                mailTemplateAdapter.notifyDataSetChanged();
            }
        }else{
            xlistview.setVisibility(View.VISIBLE);
            if(mailTemplateAdapter == null) {
                mailTemplateAdapter = new MailTemplateAdapter(this,mapList);
                xlistview.setAdapter(mailTemplateAdapter);
            } else {
                mailTemplateAdapter.list = mapList;
                mailTemplateAdapter.notifyDataSetChanged();
            }
            mailTemplateAdapter.parentHandler = messageHandler;
        }
    }




    @Override
    public void finish() {
        super.finish();
    }

    @Override
    public void onRefresh(int id) {
        getMailTemplateList();
    }

    @Override
    public void onLoadMore(int id) {
        getMailTemplateListMore();
    }

}
