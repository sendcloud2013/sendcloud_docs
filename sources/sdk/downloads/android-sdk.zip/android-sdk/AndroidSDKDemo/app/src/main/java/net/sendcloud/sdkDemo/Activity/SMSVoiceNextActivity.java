package net.sendcloud.sdkDemo.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import net.sendcloud.androidsdk.R;

import net.sendcloud.sendcloudsmslib.sms.SMSApi;
import net.sendcloud.sendcloudsmslib.sms.SMSApi.ResultCallBack;

public class SMSVoiceNextActivity extends Activity {

    private TextView textView, phone, temp;
    private EditText code;
    private ImageView delete;
    private Boolean voiceOrCode;
    private String phoneNumber;
    private String countryCode = "";
    private StringBuffer verificationCode;

    private SMSApi smsApi; //短信sdk主对象

    private int mark = RETRY_INTERVAL;

    private static final int RETRY_INTERVAL = 10; //设置一个倒计时时间

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_next);

        textView = (TextView)findViewById(R.id.re_send) ;
        temp = (TextView)findViewById(R.id.temp);
        phone = (TextView)findViewById(R.id.number);
        code = (EditText)findViewById(R.id.code);

        delete = (ImageView)findViewById(R.id.delete_2);

        Bundle bundle = this.getIntent().getExtras();
        voiceOrCode = bundle.getBoolean("voiceOrCode");
        countryCode = bundle.getString("countryCode");
        phoneNumber = bundle.getString("phoneNumber");
        phone.setText(getNumber(phoneNumber));

        code.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if(code.getText().length() == 1)
                    delete.setVisibility(View.VISIBLE);
                if(code.getText().length() == 0)
                    delete.setVisibility((View.GONE));
            }
        });
        //初始化sdk主操作对象
        smsApi =  SMSApi.getInstance();
        requestSMSApi(voiceOrCode);
    }

    private String getNumber(String number){
        char[] temp = number.toCharArray();
        StringBuilder sb = new StringBuilder();
        sb.append("+").append(countryCode).append(" ");
        for(int i=0; i<temp.length; i++){
            if(i == 3 || i == 7)
                sb.append(" ");
            sb.append(temp[i]);
        }
        return sb.toString();
    }

    private void requestSMSApi(final Boolean voiceOrCode){
        temp.setEnabled(false);
        mark = RETRY_INTERVAL;
        temp.setText(R.string.relate);
        countDown();

        int numcode = (int) ((Math.random() * 9 + 1) * 100000);
        Log.d("code", numcode+"");
        verificationCode = new StringBuffer(numcode + "");


        /**
         * 请求短信验证码
         *
         * code	返回码: 200 成功; 500 服务器内部错误;(服务器返回)
         * -2 本地网络异常; -3 服务器网络异常;-4 解析错误;-5初始化异常;
         * -6 手机号码不正确 ; -7 模板id为空;-8 变量格式错误
         * result	返回结果,JSON格式.错误或者无返回值时为空.
         * message 返回信息 成功或错误原因.
         */
        if(voiceOrCode) {
            //调用语音短信发送接口
            smsApi.sendVoiceSMS(phoneNumber,verificationCode.toString(), new ResultCallBack() {
                @Override
                public void onResult(int code, String result, String message) {
                    // TODO Auto-generated method stub
                    if(code == 200){
                        //调用成功
                        Toast.makeText(getApplicationContext(), "语音验证码已发送", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } else {
            //短信模板id
            int templateId = 349;
            //变量替换
            String vars= "code="+numcode;
            //调用短信模板发送接口
            smsApi.sendTemplateSMS(phoneNumber,templateId,vars, new ResultCallBack() {
                @Override
                public void onResult(int code, String result, String message) {
                    // TODO Auto-generated method stub
                    if(code == 200){
                        //调用成功
                        Toast.makeText(getApplicationContext(), "验证码已发送", Toast.LENGTH_SHORT).show();
                    }else { //返回错误消息
                        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void showDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(getString(R.string.not_receive));
        builder.setMessage(getString(R.string.retips)+phoneNumber);
        builder.setNeutralButton(getString(R.string.cancel), null);
        builder.setNegativeButton(getString(R.string.sure), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                requestSMSApi(voiceOrCode);
            }
        });
        builder.create().show();
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.btn_next:
                if (code.getText().toString().equals(verificationCode.toString())) {
                    Toast.makeText(getApplicationContext(), "验证成功！", Toast.LENGTH_SHORT).show();
                    this.finish();
                } else
                    Toast.makeText(getApplicationContext(), "验证码不正确", Toast.LENGTH_SHORT).show();
                break;
            case R.id.delete_2:
                phone.setText("");
                break;
            case R.id.temp:
                showDialog();
                break;
        }
    }

    final Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what){
                case 1:
                    String tmp = mark + "S";
                    textView.setText(tmp);
                    break;
                case 2:
                    textView.setText("");
                    temp.setEnabled(true);
                    temp.setText(getString(R.string.not_receive));
                    break;
            }
        }
    };

    //倒计时方法
    private void countDown(){
        new Thread( new Runnable() {
            @Override
            public void run() {
                while (mark > -1) {
                    if (mark == RETRY_INTERVAL){
                        Message msg0 = new Message();
                        msg0.what = 0;
                        mHandler.sendMessage(msg0);
                    }
                    Message msg = new Message();
                    msg.what = 1;
                    mHandler.sendMessage(msg);

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    mark--;
                    if(mark == -1){
                        Message msg1 = new Message();
                        msg1.what = 2;
                        mHandler.sendMessage(msg1);
                    }
                }
            }
        }).start();
    }

}
