package net.sendcloud.sdkDemo.Activity;

import android.app.Activity;
import android.os.Bundle;


import net.sendcloud.sdkDemo.utils.CountryListPageLayout;


public class CountryActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CountryListPageLayout layout = new CountryListPageLayout(this);
        setContentView(layout.getLayout());
    }
}
