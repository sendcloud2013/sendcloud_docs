package net.sendcloud.sdkDemo.Activity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


import net.sendcloud.androidsdk.R;
import net.sendcloud.sdkDemo.utils.TitleBar;


import net.sendcloud.sendcloudmaillib.mail.MailApi;
import net.sendcloud.sendcloudmaillib.mail.MailApi.ResultCallBack;

public class SendMailActivity extends Activity {
    TitleBar titleBar;
    private EditText clientAddrs; //邮件地址
    private EditText mailSubject;  //邮件标题
    private EditText mailContent;   //邮件内容

    private MailApi mailApi; //邮件sdk主对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendmail);
        //初始化sdk主操作对象
        mailApi =  MailApi.getInstance();
        initView();
    }

    private void initView() {
        titleBar = (TitleBar)findViewById(R.id.titlebar);
        titleBar.setTitle(getString(R.string.btn_sendmail));
        clientAddrs = (EditText)findViewById(R.id.client_addrs);
        mailSubject = (EditText)findViewById(R.id.client_addrs);
        mailContent = (EditText)findViewById(R.id.mail_content);
    }

    /**
     * 邮件发送
     */
      private void sendMail(){
          /**
           * 普通邮件发送
           *
           * code	返回码: 200 成功; 1 错误;(服务器返回)
           * -2 本地网络异常; -3 服务器网络异常;-4 解析错误;-5初始化异常;
           * -6 发送者地址不正确 ; -7 接收者地址不正确;-8 邮件标题为空 -9 邮件内容为空
           * result	返回结果,JSON格式.错误或者无返回值时为空.
           * message 返回信息 成功或错误原因.
           */
          String to = clientAddrs.getText().toString(); //发件人地址
          String subject = mailSubject.getText().toString(); //邮件标题
          String content = mailContent.getText().toString(); //邮件内容
          String from = "admin@qq.com"; //发件人
          mailApi.sendMailSimple(to,subject,content,from, new ResultCallBack() {
              @Override
              public void onResult(int code, String result, String message) {
                  if(code == 200){
                      //调用成功
                      Toast.makeText(getApplicationContext(), "邮件发送成功！", Toast.LENGTH_SHORT).show();
                      finish();
                  }else { //返回错误消息
                      Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                  }
              }
          });
      }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.send_mail:
                sendMail();
                break;
        }
    }
}
