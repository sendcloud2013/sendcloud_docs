package net.sendcloud.sdkDemo.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;
import net.sendcloud.androidsdk.R;

import java.util.List;
import java.util.Map;
import android.view.View.OnClickListener;
import android.os.Message;
import android.os.Handler;

/**
 * Created by admin on 2017/3/15.
 */

public class MailTemplateAdapter extends BaseAdapter {

    private Context context;
    public List<Map<String, Object>> list;
    private LayoutInflater inflater;

    public Handler parentHandler;

    public MailTemplateAdapter(Context context, List<Map<String, Object>> list) {
        this.context = context;
        this.list = list;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if(convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.mail_template_list_item, null);
            holder.layout = (LinearLayout) convertView.findViewById(R.id.mail_template_item_layout);
            holder.name = (TextView) convertView.findViewById(R.id.name_text);
            holder.invokeName = (TextView) convertView.findViewById(R.id.invokeName_text);
            holder.templateType = (TextView) convertView.findViewById(R.id.templateType_text);
            holder.templateStat = (TextView) convertView.findViewById(R.id.templateStat_text);
            holder.subject = (TextView) convertView.findViewById(R.id.subject_text);
            holder.gmtCreated = (TextView) convertView.findViewById(R.id.gmtCreated_text);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.layout.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v) {
                Message msg = new Message();
                msg.what = 1;
                msg.arg1 = position;
                parentHandler.handleMessage(msg);
            }
        });


        Map map = list.get(position);
        if(map.get("gmtCreated")!=null){
            holder.gmtCreated.setText("模板创建时间："+map.get("gmtCreated").toString());
        }

        if(map.get("subject")!=null){
            holder.subject.setText("邮件标题："+ map.get("subject").toString());
        }

        if(map.get("templateStat")!=null){
            holder.templateStat.setText("模板状态："+ map.get("templateStat").toString());
        }

        if(map.get("templateType")!=null){
            if(map.get("templateType").equals("0")){
                holder.templateType.setText("模板类型：触发");
            }
            if(map.get("templateType").equals("1")){
                holder.templateType.setText("模板类型：批量");
            }
        }

        if(map.get("invokeName")!=null){
            holder.invokeName.setText("模板调用名："+ map.get("invokeName").toString());
        }

        if(map.get("name")!=null){
            holder.name.setText("模板名称："+ map.get("name").toString());
        }
        return convertView;
    }

    class ViewHolder {
        private TextView name;
        private TextView invokeName;
        private TextView templateType;
        private TextView templateStat;
        private TextView subject;
        private TextView gmtCreated;
        private LinearLayout layout;
    }
}
