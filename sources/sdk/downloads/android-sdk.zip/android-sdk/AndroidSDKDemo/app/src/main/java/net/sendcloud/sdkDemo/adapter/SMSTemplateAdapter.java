package net.sendcloud.sdkDemo.adapter;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;


import net.sendcloud.androidsdk.R;

import java.util.List;
import java.util.Map;

/**
 * Created by admin on 2017/3/15.
 */

public class SMSTemplateAdapter extends BaseAdapter {

    private Context context;
    public List<Map<String, Object>> list;
    private LayoutInflater inflater;

    public Handler parentHandler;

    public SMSTemplateAdapter(Context context, List<Map<String, Object>> list) {
        this.context = context;
        this.list = list;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return list.size();
    }

    @Override
    public Object getItem(int position) {
        return list.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final ViewHolder holder;
        if(convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.sms_template_list_item, null);
            holder.layout = (LinearLayout) convertView.findViewById(R.id.sms_template_item_layout);
            holder.templateId = (TextView) convertView.findViewById(R.id.templateId_text);
            holder.smsType = (TextView) convertView.findViewById(R.id.smsType_text);
            holder.templateName = (TextView) convertView.findViewById(R.id.templateName_text);
            holder.isVerify = (TextView) convertView.findViewById(R.id.isVerify_text);
            holder.templateContent = (TextView) convertView.findViewById(R.id.templateContent_text);
            holder.templateCreateTime = (TextView) convertView.findViewById(R.id.templateCreateTime_text);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.layout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Message msg = new Message();
                msg.what = 1;
                msg.arg1 = position;
                parentHandler.handleMessage(msg);
            }
        });

        Map map = list.get(position);
        if(map.get("templateCreateTime")!=null){
            holder.templateCreateTime.setText("模板创建时间："+map.get("templateCreateTime").toString());
        }

        if(map.get("templateContent")!=null){
            holder.templateContent.setText("模板内容："+ map.get("templateContent").toString());
        }

        if(map.get("isVerify")!=null){
            holder.isVerify.setText(map.get("isVerify").toString());
        }

        if(map.get("templateName")!=null){
            holder.templateName.setText("模板名称："+ map.get("templateName").toString());
        }

        if(map.get("smsType")!=null){
            holder.smsType.setText("模板类型："+ map.get("smsType").toString());
        }

        if(map.get("templateId")!=null){
            holder.templateId.setText("模板id："+ map.get("templateId").toString());
        }
        return convertView;
    }

    class ViewHolder {
        private TextView templateId;
        private TextView smsType;
        private TextView msgType;
        private TextView templateName;
        private TextView isVerify;
        private TextView templateContent;
        private TextView templateCreateTime;
        private LinearLayout layout;
    }
}
