package net.sendcloud.sdkDemo.Activity;

import android.app.Activity;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import net.sendcloud.androidsdk.R;
import net.sendcloud.sdkDemo.utils.MEditText;
import net.sendcloud.sdkDemo.utils.TitleBar;


import net.sendcloud.sendcloudmaillib.utils.StringUtil;
import net.sendcloud.sendcloudsmslib.sms.SMSApi;
import net.sendcloud.sendcloudsmslib.sms.SMSApi.ResultCallBack;


public class SMSVerifyActivity extends Activity implements View.OnClickListener{

    private MEditText phone;
    private EditText code;
    private TextView getCode;

    private int mark = RETRY_INTERVAL;

    private static final int RETRY_INTERVAL = 10; //设置一个倒计时时间
    private StringBuffer verificationCode;

    private SMSApi smsApi; //短信sdk主对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);
        //初始化sdk主操作对象
        smsApi =  SMSApi.getInstance();
        initView();
    }

    /**
     * 请求短信接口
     */
    private void requestSMSApi(){

        //倒计时
        mark = RETRY_INTERVAL;
        countDown();

        int numcode = (int) ((Math.random() * 9 + 1) * 100000);
        Log.d("code", numcode+"");
        verificationCode = new StringBuffer(numcode + "");
        //短信模板id
        int templateId = 349;
        //变量替换
        String vars= "code="+numcode;

        /**
         * 请求短信验证码
         *
         * code	返回码: 200 成功; 500 服务器内部错误;(服务器返回)
         * -2 本地网络异常; -3 服务器网络异常;-4 解析错误;-5初始化异常;
         * -6 手机号码不正确 ; -7 模板id为空;-8 变量格式错误
         * result	返回结果,JSON格式.错误或者无返回值时为空.
         * message 返回信息 成功或错误原因.
         */
        smsApi.sendTemplateSMS(phone.getText(),templateId,vars, new ResultCallBack() {

            @Override
            public void onResult(int code, String result, String message) {
                if(code == 200){
                    //调用成功
                    Toast.makeText(getApplicationContext(), "验证码已发送", Toast.LENGTH_SHORT).show();
                }else {
                    //返回错误消息
                    Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    /**
     * 初始化界面控件
     */
    private void initView() {
        TitleBar titleBar = (TitleBar)findViewById(R.id.titlebar);
        phone = (MEditText)findViewById(R.id.phone);
        code = (EditText) findViewById(R.id.verify_code);
        getCode = (TextView) findViewById(R.id.get_code);
        titleBar.setTitle(getString(R.string.title_sms));
        phone.setHint("手机号码");
    }

    @Override
    public void onClick(View v){
        switch (v.getId()){
            case R.id.get_code:
                if(!StringUtil.isNullOrEmpty(phone.getText())){
                    requestSMSApi();
                }else{
                    Toast.makeText(getApplicationContext(), "请填写手机号！", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.register:
                if(StringUtil.isNullOrEmpty(code.getText().toString())){
                    Toast.makeText(getApplicationContext(), "请填写验证码！", Toast.LENGTH_SHORT).show();
                    break;
                }
                if (code.getText().toString().equals(verificationCode.toString())){
                    Toast.makeText(getApplicationContext(), "验证成功！", Toast.LENGTH_SHORT).show();
                    //下面可以写成功后的逻辑
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), "验证码不正确", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    //倒计时方法
    private void countDown(){
        new Thread( new Runnable() {
            @Override
            public void run() {
                while (mark > -1) {
                    if (mark == RETRY_INTERVAL){
                        Message msg0 = new Message();
                        msg0.what = 0;
                        mHandler.sendMessage(msg0);
                    }
                    Message msg = new Message();
                    msg.what = 1;
                    mHandler.sendMessage(msg);

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    mark--;
                    if(mark == -1){
                        Message msg1 = new Message();
                        msg1.what = 2;
                        mHandler.sendMessage(msg1);
                    }
                }
            }
        }).start();
    }

    final private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what){
                case 0:
                    getCode.setClickable(false);
                    getCode.setBackgroundColor(Color.parseColor("#dbdbdb"));
                    break;
                case 1:
                    getCode.setText(mark + "S后重新获取");
                    break;
                case 2:
                    getCode.setBackgroundColor(Color.parseColor("#a2e08d"));
                    getCode.setClickable(true);
                    getCode.setText("获取验证码");
                    break;
                default:
                    break;
            }
        }
    };

}
