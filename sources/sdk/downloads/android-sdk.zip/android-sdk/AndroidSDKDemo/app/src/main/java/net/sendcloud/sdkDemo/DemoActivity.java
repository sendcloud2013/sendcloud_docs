package net.sendcloud.sdkDemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.view.View;

import net.sendcloud.androidsdk.R;
import net.sendcloud.sdkDemo.Activity.SMSVoiceActivity;
import net.sendcloud.sdkDemo.Activity.SMSVerifyActivity;
import net.sendcloud.sdkDemo.Activity.SendMailActivity;

import net.sendcloud.sdkDemo.Activity.SendMailTemplateActivity;
import net.sendcloud.sdkDemo.Activity.SendSMSTemplateActivity;
import net.sendcloud.sdkDemo.utils.TitleBar;


public class DemoActivity extends Activity implements View.OnClickListener{
    private TitleBar titleBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send);

        titleBar = (TitleBar)findViewById(R.id.titlebar);
        titleBar.setTitle(getString(R.string.main_page));
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.mail_send:
                Intent intent1 = new Intent(this, SendMailActivity.class);
                startActivityForResult(intent1, 1);
                break;
            case R.id.sms_verify:
                Intent intent = new Intent(this, SMSVerifyActivity.class);
                startActivityForResult(intent, 1);
                break;
            case R.id.sms_voice:
                Intent intent2 = new Intent(this, SMSVoiceActivity.class);
                startActivityForResult(intent2, 1);
                break;
            case R.id.sms_template:
                Intent intent3 = new Intent(this, SendSMSTemplateActivity.class);
                startActivityForResult(intent3, 1);
                break;
            case R.id.mail_template_send:
                Intent intent4 = new Intent(this, SendMailTemplateActivity.class);
                startActivityForResult(intent4, 1);
                break;
            default:
                break;
        }
    }
}
