package net.sendcloud.sdkDemo.Activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;


import net.sendcloud.sdkDemo.adapter.SMSTemplateAdapter;
import net.sendcloud.sdkDemo.xlistview.XListView;
import net.sendcloud.sdkDemo.xlistview.XListView.IXListViewListener;


import net.sendcloud.sendcloudmaillib.utils.StringUtil;
import net.sendcloud.sendcloudsmslib.sms.SMSApi;
import net.sendcloud.sendcloudsmslib.sms.SMSApi.ResultCallBack;
import net.sendcloud.sendcloudsmslib.utils.JsonUtil;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Map;

import static android.R.id.list;
import net.sendcloud.androidsdk.R;

public class SMSTemplateListActivity extends AppCompatActivity implements IXListViewListener{

    private XListView xlistview;

    private SMSApi smsApi; //短信sdk主对象

    private List<Map<String, Object>> mapList;

    private SMSTemplateAdapter smsTemplateAdapter;

    public  Handler messageHandler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_template_list);
        xlistview = (XListView) findViewById(list);
        xlistview.setPullLoadEnable(true);
        xlistview.setRefreshTime();
        xlistview.setXListViewListener(this,1);
        //初始化sdk主操作对象
        smsApi =  SMSApi.getInstance();

        messageHandler = new Handler(){
            public void handleMessage(Message msg) {
                if (msg.what == 1) {
                    int position =  msg.arg1;
                    Map<String, Object> map = mapList.get(position);
                    Intent intent = new Intent();
                    intent.putExtra("templateName",map.get("templateName").toString());
                    intent.putExtra("templateId",Integer.valueOf(map.get("templateId").toString()));
                    intent.putExtra("templateContent",map.get("templateContent").toString());
                    setResult(Activity.RESULT_OK, intent);
                    finish();
                }
            }
        };

        //适配器添加查询结果，并加到ListView中显示
        getSMSTemplateList();
    }

    private void getSMSTemplateList() {
        /**
         * 获取短信模板列表
         *
         * code	返回码: 200 成功; 500 服务器内部错误;(服务器返回)
         * -2 本地网络异常; -3 服务器网络异常;-4 解析错误;-5初始化异常;
         * result	返回结果,JSON格式.错误或者无返回值时为空.
         * message 返回信息 成功或错误原因.
         */
        String isVerifyStr = "1";//是否通过验证；"0"待审核 "1"审核通过"-1"审核不通过 null全部
        smsApi.getSMSTemplate(isVerifyStr, new ResultCallBack() {
            @Override
            public void onResult(int code, String result, String message) {
                //调用成功
                if(code == 200){
                    if(!StringUtil.isNullOrEmpty(result)){
                        Log.d("send_result", result);
                        try{
                            JSONObject jsonObject = new JSONObject(result);
                            JSONArray list = jsonObject.optJSONArray("list");
                            if(list!=null){
                                mapList = (List<Map<String, Object>>)JsonUtil.jsonParse(list.toString());
                                changListView();
                            }
                        }catch (JSONException e){

                        }
                    }
                }else { //返回错误消息
                    Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    private void changListView(){
        xlistview.setPullLoadEnable(false);
        xlistview.setRefreshTime();
        xlistview.stopRefresh();
        xlistview.stopLoadMore();
        if(mapList.size()==0){
            xlistview.setVisibility(View.GONE);
            if(smsTemplateAdapter != null) {
                smsTemplateAdapter.list = mapList;
                smsTemplateAdapter.notifyDataSetChanged();
            }
        }else{
            xlistview.setVisibility(View.VISIBLE);
            if(smsTemplateAdapter == null) {
                smsTemplateAdapter = new SMSTemplateAdapter(this,mapList);
                xlistview.setAdapter(smsTemplateAdapter);
            } else {
                smsTemplateAdapter.list = mapList;
                smsTemplateAdapter.notifyDataSetChanged();
            }
            smsTemplateAdapter.parentHandler = messageHandler;
        }
    }




    @Override
    public void finish() {
        super.finish();
    }

    @Override
    public void onRefresh(int id) {
        getSMSTemplateList();
    }

    @Override
    public void onLoadMore(int id) {

    }

}
