package net.sendcloud.sdkDemo;

import android.app.Application;

import net.sendcloud.sendcloudmaillib.mail.MailCommon;
import net.sendcloud.sendcloudsmslib.sms.SMSCommon;

/**
 * Created by admin on 2017/4/10.
 */

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        // 短信api用户
        String smsApiUser = "sms_delong";
        //短信api用户密钥
        String smsPassword = "12345";
        //全局初始化短信发送接口
        SMSCommon.initSDK(getApplicationContext(),smsApiUser,smsPassword);

        // 邮件api用户
        String mailApiUser = "sctest";
        //邮件api用户密钥
        String mailPassword = "12345";
        //全局初始化邮件发送接口
        MailCommon.initSDK(getApplicationContext(),mailApiUser,mailPassword);
        super.onCreate();

    }
}
