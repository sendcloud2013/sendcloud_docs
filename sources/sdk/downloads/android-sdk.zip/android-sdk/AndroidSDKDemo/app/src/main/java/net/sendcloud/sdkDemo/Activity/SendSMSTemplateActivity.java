package net.sendcloud.sdkDemo.Activity;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import net.sendcloud.androidsdk.R;
import net.sendcloud.sdkDemo.utils.TitleBar;
import net.sendcloud.sendcloudsmslib.sms.SMSApi;

import static net.sendcloud.androidsdk.R.id.sms_template;

public class SendSMSTemplateActivity extends Activity{

    TitleBar titleBar;
    private EditText clientAddrs; //手机号
    private TextView smsTemplate;//邮件模板
    private TextView smsContent; //邮件内容
    private SMSApi smsApi; //短信sdk主对象
    private EditText smsVars; //短信变量

    private Integer templateId; //模板调用名

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sendsms_template);

        //初始化sdk主操作对象
        smsApi =  SMSApi.getInstance();
        initView();
    }


    private void initView() {
        titleBar = (TitleBar)findViewById(R.id.titlebar);
        titleBar.setTitle(getString(R.string.btn_sendmail_template));
        clientAddrs = (EditText)findViewById(R.id.client_addrs);
        smsTemplate = (TextView)findViewById(sms_template);
        smsContent = (TextView)findViewById(R.id.sms_content);
        smsVars = (EditText)findViewById(R.id.sms_vars);
    }

    /**
     * 邮件发送
     */
    private void sendTemplateSMS(){

        String phone = clientAddrs.getText().toString(); //发件人地址
        String vars = smsVars.getText().toString();

        /**
         * 请求短信验证码
         *
         * code	返回码: 200 成功; 500 服务器内部错误;(服务器返回)
         * -2 本地网络异常; -3 服务器网络异常;-4 解析错误;-5初始化异常;
         * -6 手机号码不正确 ; -7 模板id为空;-8 变量格式错误
         * result	返回结果,JSON格式.错误或者无返回值时为空.
         * message 返回信息 成功或错误原因.
         */
        smsApi.sendTemplateSMS(phone,templateId,vars, new SMSApi.ResultCallBack() {

            @Override
            public void onResult(int code, String result, String message) {
                if(code == 200){
                    //调用成功
                    Toast.makeText(getApplicationContext(), "短信已发送", Toast.LENGTH_SHORT).show();
                }else {
                    //返回错误消息
                    Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    public void onClick(View v){
        switch (v.getId()){
            case R.id.send_sms:
                if(templateId!=null){
                    sendTemplateSMS();
                }else{
                    Toast.makeText(getApplicationContext(), "请选择模板", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.select_sms_template:
                Intent intent = new Intent(this, SMSTemplateListActivity.class);
                startActivityForResult(intent, 1);
                break;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == Activity.RESULT_OK){
            String templateName = data.getExtras().getString("templateName");
            templateId = data.getExtras().getInt("templateId");
            String templateContent = data.getExtras().getString("templateContent");
            smsTemplate.setText(templateName);
            smsContent.setText(templateContent);
        }
    }

}
