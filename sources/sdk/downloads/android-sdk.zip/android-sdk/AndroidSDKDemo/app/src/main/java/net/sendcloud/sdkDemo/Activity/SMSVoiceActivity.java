package net.sendcloud.sdkDemo.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import net.sendcloud.androidsdk.R;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class SMSVoiceActivity extends Activity {

    private EditText phone;
    private TextView country, code;
    private ImageView delete;
    private CheckBox checkBox;
    private String countryCode = "86";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        initView();
    }

    private void initView() {
        phone = (EditText)findViewById(R.id.editText);
        country = (TextView)findViewById(R.id.country);
        code = (TextView)findViewById(R.id.mark);
        delete = (ImageView)findViewById(R.id.delete);
        checkBox = (CheckBox)findViewById(R.id.use_voice);
        phone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                if(phone.getText().length() == 1)
                    delete.setVisibility(View.VISIBLE);
                if(phone.getText().length() == 0)
                    delete.setVisibility((View.GONE));
            }
        });

    }


    public boolean isMobileNum(String mobiles) {
        Pattern p = Pattern
                .compile("^((13[0-9])|(15[^4,\\D])|(18[0,5-9]))\\d{8}$");
        Matcher m = p.matcher(mobiles);
        return m.matches();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(resultCode == Activity.RESULT_OK){
            String name = data.getExtras().getString("countryName");
            countryCode = data.getExtras().getString("countryCode");
            country.setText(name);
            this.code.setText(countryCode);
        }
    }

    private void showDialog(){
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.sure_phone));
        builder.setMessage(getString(R.string.sure_tips)
                +getNumber(phone.getText().toString()));

        builder.setNeutralButton(getString(R.string.cancel), null);
        builder.setNegativeButton(getString(R.string.sure), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(SMSVoiceActivity.this, SMSVoiceNextActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("countryCode", countryCode);
                bundle.putString("phoneNumber", phone.getText().toString());
                bundle.putBoolean("voiceOrCode", checkBox.isChecked());
                intent.putExtras(bundle);
                startActivityForResult(intent, 1);
            }
        });

        builder.create().show();
    }

    private String getNumber(String number){
        char[] temp = number.toCharArray();
        StringBuilder sb = new StringBuilder();
        sb.append("+").append(countryCode).append(" ");
        for(int i=0; i<temp.length; i++){
            if(i == 3 || i == 7)
                sb.append(" ");
            sb.append(temp[i]);
        }
        return sb.toString();
    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.next:
                if (!isMobileNum(phone.getText().toString())) {
                    Toast.makeText(getApplicationContext(), getString(R.string.error_tips),
                            Toast.LENGTH_SHORT).show();
                }else{
                    showDialog();
                }
                break;
            case R.id.delete:
                phone.setText("");
                break;
            case R.id.select_country:
                Intent intent = new Intent(this, CountryActivity.class);
                startActivityForResult(intent, 1);
                break;
            default:
                break;
        }
    }
}
