package net.sendcloud.sdkDemo.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;

/**国家列表页面布局*/
public class CountryListPageLayout extends BasePageLayout implements GroupListView.OnItemClickListener{

	private CountryListView countryList;

	public CountryListPageLayout(Context c) {
		super(c);
	}

	protected void onCreateContent(LinearLayout parent) {
		countryList = new CountryListView(context);

		LinearLayout.LayoutParams listParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
				LinearLayout.LayoutParams.WRAP_CONTENT, 1);
		countryList.setLayoutParams(listParams);
		countryList.setOnItemClickListener(this);

		parent.addView(countryList);
	}

	@Override
	public void onItemClick(GroupListView parent, View view, int group, int position) {
		if(0 <= position){
			String[] countrys = countryList.getCountry(group, position);

			Log.d("----------->", countrys[1]);
			Intent intent = new Intent();
			intent.putExtra("countryName",countrys[0]);
			intent.putExtra("countryCode", countrys[1]);
			((Activity)context).setResult(Activity.RESULT_OK, intent);
			((Activity)context).finish();
		}
	}
}
