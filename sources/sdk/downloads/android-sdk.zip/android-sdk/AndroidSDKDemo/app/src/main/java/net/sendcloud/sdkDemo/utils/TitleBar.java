package net.sendcloud.sdkDemo.utils;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import net.sendcloud.androidsdk.R;


public class TitleBar extends RelativeLayout {

    private TextView title;

    public TitleBar(Context context) {
        this(context, null);
    }

    public TitleBar(final Context context, AttributeSet attrs){
        super(context, attrs);
        SizeHelper.prepare(context);
        LayoutInflater.from(context).inflate(R.layout.tools_titlebar, this, true);
        ImageView leftButton = (ImageView) findViewById(R.id.left_btn);
        title = (TextView) findViewById(R.id.title);
        RelativeLayout parent = (RelativeLayout)findViewById(R.id.titlee_parent);

        leftButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                ((Activity)context).finish();
            }
        });

        LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                SizeHelper.fromPx(74));
        parent.setLayoutParams(params);
    }

    public void setTitle(String title){
        this.title.setText(title);
    }

}
